import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class PanelCmd extends JPanel
{
  private JButton btnReset;
  private JPanel[][] ensPanel;
  private Tuile[][] ensTuile;
  private JLabel[][] ensLabel;

}
